n = 3
sym = "*"
for i in range(n):
    for j in range(n):
        if i == j:
            print(sym, end="")
        else:
            print(" ", end="")
    print("")