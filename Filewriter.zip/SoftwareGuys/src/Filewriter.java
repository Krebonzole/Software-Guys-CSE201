import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class Filewriter {
	public static void main(String[] args) {
		try(Scanner fin = new Scanner(new File("input.txt"))) {
			try(PrintWriter pw = new PrintWriter("transactions.txt")) {
				String bName = " ", fName = " ", lName = " ", type = " ";
				int sTotal = 0;
				int amount = 0;
				int finTotal = 0;
				String len;
				String border = "";
				for(int i = 0; i < 64; i++) border += "-";
				fin.nextLine();
				while(fin.hasNextLine()) {
					String[] parts = fin.nextLine().split("\t");
					bName = parts[0];
					fName = parts[1];
					lName = parts[2];
					sTotal = Integer.parseInt(parts[3]);
					type = parts[4];
					amount = Integer.parseInt(parts[5]);
					if(type.equals("w") || type.equals("W"))
						finTotal = sTotal - amount;
					else {
						finTotal = sTotal + amount;
					}
					len = bName + " | " + fName + " " + lName;
					
					int dif = 50 - len.length();
					String out = String.format("| %s  %" + dif + "d -> %d | %n", len, sTotal, finTotal);
					pw.write(border + "\n");
					pw.write(out);
				}
				pw.write(border);
				pw.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} catch(Exception e) {
			e.printStackTrace();
		} 		
	}
}


